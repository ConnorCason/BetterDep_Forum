export const FETCH_USER_PROFILE_START = 'fetch_user_profile_start';
export const FETCH_USER_PROFILE_SUCCESS = 'fetch_user_profile_success';
export const FETCH_USER_PROFILE_FAILURE = 'fetch_user_profile_failure';
