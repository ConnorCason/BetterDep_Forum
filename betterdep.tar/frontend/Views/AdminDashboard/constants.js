export const GET_ALL_INFO_START = 'get_all_info_start';
export const GET_ALL_INFO_SUCCESS = 'get_all_info_success';
export const GET_ALL_INFO_FAILURE = 'get_all_info_failure';

export const CREATE_FORUM = 'create_forum';
export const CREATE_FORUM_SUCCESS = 'create_forum_success';
export const CREATE_FORUM_FAILURE = 'create_forum_failure';

export const DELETE_FORUM = 'delete_forum';
export const DELETE_FORUM_SUCCESS = 'delete_forum_success';
export const DELETE_FORUM_FAILURE = 'delete_forum_failure';
