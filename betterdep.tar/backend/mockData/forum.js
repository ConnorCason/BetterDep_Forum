const forums = [
  {
    'forum_id': 0,
    'forum_slug': 'general',
    'forum_name': 'General',
  },
  {
    'forum_id': 1,
    'forum_slug': 'react',
    'forum_name': 'React',
  },
  {
    'forum_id': 2,
    'forum_slug': 'redux',
    'forum_name': 'Redux',
  },
];

module.exports = forums;
