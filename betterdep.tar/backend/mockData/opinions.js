const opinions = [
  {
    'discussion_id': '58c641904e457708a7147417',
    'user_id': '58c242e2fb2e150d2570e02b',
    'date': 1486450269704,
    'content': 'Awesome stuffs!',
  },
  {
    'discussion_id': '58c641904e457708a7147417',
    'user_id': '58c242e2fb2e150d2570e02b',
    'date': 1486450269704,
    'content': 'Awesome stuffs really!',
  },
  {
    'discussion_id': '58c641cf88336b08c76f3b50',
    'user_id': '58c242a96ba2030d170f86f9',
    'date': 1486450269704,
    'content': 'Great job dude!',
  },
  {
    'discussion_id': '58c641cf88336b08c76f3b50',
    'user_id': '58c242a96ba2030d170f86f9',
    'date': 1486450269704,
    'content': 'These discussions!!!',
  },
];

module.exports = opinions;
